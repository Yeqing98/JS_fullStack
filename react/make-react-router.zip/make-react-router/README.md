核心组件
## react-router
平台相关
## react-router-dom

## hash history
# 后面的东西不会发送到服务端

## history
pushState js 控制的时候 路由改变而不刷新页面 页面路由的变化是由 js 控制的
刷新的时候， 整个js都会加载一次， 请求了一个后端url

解决办法：再交给前端处理
代码：
nginx