## 即将移除

componentWillMount
componentWillReceiveProps
componentWillUpdate

## getDerivedStateFromProps()
方法的16.3版本与之后的16.4和16.5有所调整：

在16.3版本上，该方法仅在props变动时才会被触发。

在16.3之后的版本上，该方法调整为props和state的变动都会触发该方法。


## ref
stringRef 
method
obeRef.current 